package br.com.faculdadedelta.resource;

import java.net.URI;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import br.com.faculdadedelta.model.ContatoEletronico;
import br.com.faculdadedelta.service.ContatoEletronicoService;

@RestController
@RequestMapping("/contatosEletonicos")
public class ContatoEletronicoResource {

	@Autowired
	private ContatoEletronicoService contatoEletronicoService;

	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	public ContatoEletronico inserir(@RequestBody @Valid ContatoEletronico contatoEletronico,
			HttpServletResponse response) {

		ContatoEletronico contatoEletronicoCadastrado = contatoEletronicoService.inserir(contatoEletronico);

		URI uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
				.buildAndExpand(contatoEletronico.getId()).toUri();

		response.setHeader(HttpHeaders.LOCATION, uri.toString());

		return contatoEletronicoCadastrado;
	}

	@GetMapping
	@ResponseStatus(HttpStatus.OK)
	public List<ContatoEletronico> listar() {
		return contatoEletronicoService.listar();
	}

	@GetMapping("/{id}")
	@ResponseStatus(HttpStatus.OK)
	public ContatoEletronico pesquisarPorId(@PathVariable("id") Long id) {
		return contatoEletronicoService.pesquisarPorId(id);
	}

	@PutMapping("/{id}")
	@ResponseStatus(HttpStatus.OK)
	public ContatoEletronico alterar(@RequestBody @Valid ContatoEletronico contatoEletronico,
			@PathVariable("id") Long id) {
		return contatoEletronicoService.alterar(contatoEletronico, id);
	}

	@DeleteMapping("/{id}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void excluir(@PathVariable("id") Long id) {
		contatoEletronicoService.excluir(id);
	}

}
