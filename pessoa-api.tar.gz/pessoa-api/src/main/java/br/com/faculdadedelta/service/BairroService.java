package br.com.faculdadedelta.service;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.faculdadedelta.model.Bairro;
import br.com.faculdadedelta.repository.BairroRepository;

@Service
public class BairroService {

	@Autowired
	private BairroRepository bairroRepository;

	@Transactional
	public Bairro inserir(Bairro bairro) {
		bairro.setId(null);
		return bairroRepository.save(bairro);
	}

	public Bairro pesquisarPorId(Long id) {
		return bairroRepository.findById(id).orElseThrow(() -> new EmptyResultDataAccessException(1));
	}

	@Transactional
	public Bairro alterar(Bairro bairro, Long id) {
		// busca no banco de dados para garantir que o bairro não seja nulo
		Bairro bairroPesquisado = pesquisarPorId(id);
		/*
		 * copia dos novos dados para que não seja persistido os mesmo dados que ja
		 * existiam no banco
		 */
		BeanUtils.copyProperties(bairro, bairroPesquisado, "id");
		return bairroRepository.save(bairroPesquisado);
	}

	@Transactional
	public void excluir(Long id) {
		bairroRepository.deleteById(id);
	}

	public List<Bairro> listar() {
		return bairroRepository.findAll();
	}
}
