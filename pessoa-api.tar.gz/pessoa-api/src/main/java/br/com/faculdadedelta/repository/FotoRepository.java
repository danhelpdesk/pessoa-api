package br.com.faculdadedelta.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.faculdadedelta.model.Foto;

public interface FotoRepository extends JpaRepository<Foto, Long>{

}



