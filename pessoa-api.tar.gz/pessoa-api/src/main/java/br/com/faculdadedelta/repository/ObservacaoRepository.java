package br.com.faculdadedelta.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.faculdadedelta.model.Observacao;

public interface ObservacaoRepository extends JpaRepository<Observacao, Long> {

}
