package br.com.faculdadedelta.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import br.com.faculdadedelta.model.type.TipoTelefone;

@Entity
public class Telefone {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String ddd;
	private String prefixo;
	private String sufixo;
	public TipoTelefone tipoTelefone;
	private String descricaoTelefone;
	private String codigoPais;

	public String toString() {
		return null;
	}

	public Telefone() {
		super();
	}

	public Telefone(Long id, String ddd, String prefixo, String sufixo, TipoTelefone tipoTelefone,
			String descricaoTelefone, String codigoPais) {
		super();
		this.id = id;
		this.ddd = ddd;
		this.prefixo = prefixo;
		this.sufixo = sufixo;
		this.tipoTelefone = tipoTelefone;
		this.descricaoTelefone = descricaoTelefone;
		this.codigoPais = codigoPais;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDdd() {
		return ddd;
	}

	public void setDdd(String ddd) {
		this.ddd = ddd;
	}

	public String getPrefixo() {
		return prefixo;
	}

	public void setPrefixo(String prefixo) {
		this.prefixo = prefixo;
	}

	public String getSufixo() {
		return sufixo;
	}

	public void setSufixo(String sufixo) {
		this.sufixo = sufixo;
	}

	public TipoTelefone getTipoTelefone() {
		return tipoTelefone;
	}

	public void setTipoTelefone(TipoTelefone tipoTelefone) {
		this.tipoTelefone = tipoTelefone;
	}

	public String getDescricaoTelefone() {
		return descricaoTelefone;
	}

	public void setDescricaoTelefone(String descricaoTelefone) {
		this.descricaoTelefone = descricaoTelefone;
	}

	public String getCodigoPais() {
		return codigoPais;
	}

	public void setCodigoPais(String codigoPais) {
		this.codigoPais = codigoPais;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Telefone other = (Telefone) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
