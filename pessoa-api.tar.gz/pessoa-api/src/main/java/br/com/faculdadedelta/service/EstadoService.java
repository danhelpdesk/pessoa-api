package br.com.faculdadedelta.service;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.faculdadedelta.model.Estado;
import br.com.faculdadedelta.repository.EstadoRepository;

@Service
public class EstadoService {

	@Autowired
	private EstadoRepository estadoRepository;

	@Transactional
	public Estado inserir(Estado estado) {
		estado.setId(null);
		return estadoRepository.save(estado);
	}

	public Estado pesquisarPorId(Long id) {
		return estadoRepository.findById(id).orElseThrow(() -> new EmptyResultDataAccessException(1));
	}

	@Transactional
	public Estado alterar(Estado estado, Long id) {
		// busca no banco de dados para garantir que o estado não seja nulo
		Estado estadoPesquisado = pesquisarPorId(id);
		/*
		 * copia dos novos dados para que não seja persistido os mesmo dados que ja
		 * existiam no banco
		 */
		BeanUtils.copyProperties(estado, estadoPesquisado, "id");
		return estadoRepository.save(estadoPesquisado);
	}

	@Transactional
	public void excluir(Long id) {
		estadoRepository.deleteById(id);
	}

	public List<Estado> listar() {
		return estadoRepository.findAll();
	}
}
