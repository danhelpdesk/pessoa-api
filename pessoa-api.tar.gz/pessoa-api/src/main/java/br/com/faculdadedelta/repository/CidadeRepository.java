package br.com.faculdadedelta.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.faculdadedelta.model.Cidade;

public interface CidadeRepository extends JpaRepository<Cidade, Long>{

}
