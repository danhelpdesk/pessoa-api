package br.com.faculdadedelta.model;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import br.com.faculdadedelta.model.type.TipoContatoEletronico;

@Entity
public class ContatoEletronico {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String valorContatoEletronico;

	@Enumerated(EnumType.STRING)
	private TipoContatoEletronico tipoContatoEletronico;
	private String descricaoContatoEletronico;

	public ContatoEletronico() {
		super();
	}

	public ContatoEletronico(Long id, String valorContatoEletronico, TipoContatoEletronico tipoContatoEletronico,
			String descricaoContatoEletronico) {
		super();
		this.id = id;
		this.valorContatoEletronico = valorContatoEletronico;
		this.tipoContatoEletronico = tipoContatoEletronico;
		this.descricaoContatoEletronico = descricaoContatoEletronico;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getValorContatoEletronico() {
		return valorContatoEletronico;
	}

	public void setValorContatoEletronico(String valorContatoEletronico) {
		this.valorContatoEletronico = valorContatoEletronico;
	}

	public TipoContatoEletronico getTipoContatoEletronico() {
		return tipoContatoEletronico;
	}

	public void setTipoContatoEletronico(TipoContatoEletronico tipoContatoEletronico) {
		this.tipoContatoEletronico = tipoContatoEletronico;
	}

	public String getDescricaoContatoEletronico() {
		return descricaoContatoEletronico;
	}

	public void setDescricaoContatoEletronico(String descricaoContatoEletronico) {
		this.descricaoContatoEletronico = descricaoContatoEletronico;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ContatoEletronico other = (ContatoEletronico) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
