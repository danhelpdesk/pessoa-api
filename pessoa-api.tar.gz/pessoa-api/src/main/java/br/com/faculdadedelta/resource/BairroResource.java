package br.com.faculdadedelta.resource;

import java.net.URI;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import br.com.faculdadedelta.model.Bairro;
import br.com.faculdadedelta.service.BairroService;

@RestController
@RequestMapping("/bairros")
public class BairroResource {

	@Autowired
	private BairroService bairroService;

	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	public Bairro inserir(@RequestBody @Valid Bairro bairro, HttpServletResponse response) {

		Bairro bairroCadastrado = bairroService.inserir(bairro);

		URI uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(bairro.getId()).toUri();

		response.setHeader(HttpHeaders.LOCATION, uri.toString());

		return bairroCadastrado;
	}

	@GetMapping
	@ResponseStatus(HttpStatus.OK)
	public List<Bairro> listar() {
		return bairroService.listar();
	}

	@GetMapping("/{id}")
	@ResponseStatus(HttpStatus.OK)
	public Bairro pesquisarPorId(@PathVariable("id") Long id) {
		return bairroService.pesquisarPorId(id);
	}

	@PutMapping("/{id}")
	@ResponseStatus(HttpStatus.OK)
	public Bairro alterar(@RequestBody @Valid Bairro bairro, @PathVariable("id") Long id) {
		return bairroService.alterar(bairro, id);
	}

	@DeleteMapping("/{id}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void excluir(@PathVariable("id") Long id) {
		bairroService.excluir(id);
	}

}
