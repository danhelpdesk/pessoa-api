package br.com.faculdadedelta.service;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.faculdadedelta.model.Pais;
import br.com.faculdadedelta.repository.PaisRepository;

@Service
public class PaisService {

	@Autowired
	private PaisRepository paisRepository;

	@Transactional
	public Pais inserir(Pais pais) {
		pais.setId(null);
		return paisRepository.save(pais);
	}

	public Pais pesquisarPorId(Long id) {
		return paisRepository.findById(id).orElseThrow(() -> new EmptyResultDataAccessException(1));
	}

	@Transactional
	public Pais alterar(Pais pais, Long id) {
		// busca no banco de dados para garantir que o pais não seja nulo
		Pais paisPesquisado = pesquisarPorId(id);
		/*
		 * copia dos novos dados para que não seja persistido os mesmo dados que ja
		 * existiam no banco
		 */
		BeanUtils.copyProperties(pais, paisPesquisado, "id");
		return paisRepository.save(paisPesquisado);
	}

	@Transactional
	public void excluir(Long id) {
		paisRepository.deleteById(id);
	}

	public List<Pais> listar() {
		return paisRepository.findAll();
	}
}
