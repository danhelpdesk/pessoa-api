package br.com.faculdadedelta.model.type;

public enum  TipoContatoEletronico{

	EMAIL("Email"), SKYPE("Skype"), GITHUB("Github"), LINKEDIN("Linkedin");

	private String descricao;

	private TipoContatoEletronico(String descricao) {
		this.descricao = descricao;
	}

	public String getDescricao() {
		return descricao;
	}

}
