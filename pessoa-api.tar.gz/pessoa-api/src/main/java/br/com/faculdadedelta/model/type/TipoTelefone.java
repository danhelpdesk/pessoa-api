package br.com.faculdadedelta.model.type;

public enum  TipoTelefone{

	CONTATO("Contato"), CELULAR("Celular"), FAX("Fax");

	private String descricao;

	private TipoTelefone(String descricao) {
		this.descricao = descricao;
	}

	public String getDescricao() {
		return descricao;
	}

}
