package br.com.faculdadedelta.service;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.faculdadedelta.model.Observacao;
import br.com.faculdadedelta.repository.ObservacaoRepository;

@Service
public class ObservacaoService {

	@Autowired
	private ObservacaoRepository observacaoRepository;

	@Transactional
	public Observacao inserir(Observacao observacao) {
		observacao.setId(null);
		return observacaoRepository.save(observacao);
	}

	public Observacao pesquisarPorId(Long id) {
		return observacaoRepository.findById(id).orElseThrow(() -> new EmptyResultDataAccessException(1));
	}

	@Transactional
	public Observacao alterar(Observacao observacao, Long id) {
		// busca no banco de dados para garantir que a observacao não seja nula
		Observacao observacaoPesquisado = pesquisarPorId(id);
		/*
		 * copia dos novos dados para que não seja persistido os mesmo dados que ja
		 * existiam no banco
		 */
		BeanUtils.copyProperties(observacao, observacaoPesquisado, "id");
		return observacaoRepository.save(observacaoPesquisado);
	}

	@Transactional
	public void excluir(Long id) {
		observacaoRepository.deleteById(id);
	}

	public List<Observacao> listar() {
		return observacaoRepository.findAll();
	}
}
