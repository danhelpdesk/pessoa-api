package br.com.faculdadedelta.model;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

public class InformacoesPessoa {

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate dataCadastro;
	private Boolean inativo;

	public InformacoesPessoa() {
		super();
	}

	public InformacoesPessoa(LocalDate dataCadastro, Boolean inativo) {
		super();
		this.dataCadastro = dataCadastro;
		this.inativo = inativo;
	}

	public LocalDate getDataCadastro() {
		return dataCadastro;
	}

	public void setDataCadastro(LocalDate dataCadastro) {
		this.dataCadastro = dataCadastro;
	}

	public Boolean getInativo() {
		return inativo;
	}

	public void setInativo(Boolean inativo) {
		this.inativo = inativo;
	}

}
