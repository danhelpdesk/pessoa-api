package br.com.faculdadedelta.service;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.faculdadedelta.model.Foto;
import br.com.faculdadedelta.repository.FotoRepository;

@Service
public class FotoService {

	@Autowired
	private FotoRepository fotoRepository;

	@Transactional
	public Foto inserir(Foto foto) {
		foto.setId(null);
		return fotoRepository.save(foto);
	}

	public Foto pesquisarPorId(Long id) {
		return fotoRepository.findById(id).orElseThrow(() -> new EmptyResultDataAccessException(1));
	}

	@Transactional
	public Foto alterar(Foto foto, Long id) {
		// busca no banco de dados para garantir que a foto não seja nulo
		Foto fotoPesquisado = pesquisarPorId(id);
		/*
		 * copia dos novos dados para que não seja persistido os mesmo dados que ja
		 * existiam no banco
		 */
		BeanUtils.copyProperties(foto, fotoPesquisado, "id");
		return fotoRepository.save(fotoPesquisado);
	}

	@Transactional
	public void excluir(Long id) {
		fotoRepository.deleteById(id);
	}

	public List<Foto> listar() {
		return fotoRepository.findAll();
	}
}
