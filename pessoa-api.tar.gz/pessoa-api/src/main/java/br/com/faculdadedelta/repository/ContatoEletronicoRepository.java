package br.com.faculdadedelta.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.faculdadedelta.model.ContatoEletronico;

public interface ContatoEletronicoRepository extends JpaRepository<ContatoEletronico, Long> {

}