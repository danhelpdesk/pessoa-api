package br.com.faculdadedelta.service;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.faculdadedelta.model.Usuario;
import br.com.faculdadedelta.repository.UsuarioRepository;

@Service
public class UsuarioService {

	@Autowired
	private UsuarioRepository usuarioRepository;

	@Transactional
	public Usuario inserir(Usuario usuario) {
		usuario.setId(null);
		return usuarioRepository.save(usuario);
	}

	public Usuario pesquisarPorId(Long id) {
		return usuarioRepository.findById(id).orElseThrow(() -> new EmptyResultDataAccessException(1));
	}

	@Transactional
	public Usuario alterar(Usuario usuario, Long id) {
		// busca no banco de dados para garantir que o usuario não seja nulo
		Usuario usuarioPesquisado = pesquisarPorId(id);
		/*
		 * copia dos novos dados para que não seja persistido os mesmo dados que ja
		 * existiam no banco
		 */
		BeanUtils.copyProperties(usuario, usuarioPesquisado, "id");
		return usuarioRepository.save(usuarioPesquisado);
	}

	@Transactional
	public void excluir(Long id) {
		usuarioRepository.deleteById(id);
	}

	public List<Usuario> listar() {
		return usuarioRepository.findAll();
	}
}
