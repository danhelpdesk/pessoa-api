package br.com.faculdadedelta.service;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.faculdadedelta.model.Telefone;
import br.com.faculdadedelta.repository.TelefoneRepository;

@Service
public class TelefoneService {

	@Autowired
	private TelefoneRepository telefoneRepository;

	@Transactional
	public Telefone inserir(Telefone telefone) {
		telefone.setId(null);
		return telefoneRepository.save(telefone);
	}

	public Telefone pesquisarPorId(Long id) {
		return telefoneRepository.findById(id).orElseThrow(() -> new EmptyResultDataAccessException(1));
	}

	@Transactional
	public Telefone alterar(Telefone telefone, Long id) {
		// busca no banco de dados para garantir que o telefone não seja nulo
		Telefone telefonePesquisado = pesquisarPorId(id);
		/*
		 * copia dos novos dados para que não seja persistido os mesmo dados que ja
		 * existiam no banco
		 */
		BeanUtils.copyProperties(telefone, telefonePesquisado, "id");
		return telefoneRepository.save(telefonePesquisado);
	}

	@Transactional
	public void excluir(Long id) {
		telefoneRepository.deleteById(id);
	}

	public List<Telefone> listar() {
		return telefoneRepository.findAll();
	}
}
