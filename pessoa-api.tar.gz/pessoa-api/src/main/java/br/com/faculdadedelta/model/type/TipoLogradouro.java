package br.com.faculdadedelta.model.type;

public enum TipoLogradouro {

	RUA("Rua"), AVENIDA("Avenida"), ALAMEDA("Alameda"), ESTRADA("Estrada"), RODOVIA("Rodovia"), TRAVESSA("Travessa"), TRECHO("Trecho"), VIA("Via");

	private String descricao;

	private TipoLogradouro(String descricao) {
		this.descricao = descricao;
	}

	public String getDescricao() {
		return descricao;
	}

}