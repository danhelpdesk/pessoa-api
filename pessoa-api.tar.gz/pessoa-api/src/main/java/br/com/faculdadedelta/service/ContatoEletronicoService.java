package br.com.faculdadedelta.service;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.faculdadedelta.model.ContatoEletronico;
import br.com.faculdadedelta.repository.ContatoEletronicoRepository;

@Service
public class ContatoEletronicoService {

	@Autowired
	private ContatoEletronicoRepository contatoEletronicoRepository;

	@Transactional
	public ContatoEletronico inserir(ContatoEletronico contatoEletronico) {
		contatoEletronico.setId(null);
		return contatoEletronicoRepository.save(contatoEletronico);
	}

	public ContatoEletronico pesquisarPorId(Long id) {
		return contatoEletronicoRepository.findById(id).orElseThrow(() -> new EmptyResultDataAccessException(1));
	}

	@Transactional
	public ContatoEletronico alterar(ContatoEletronico contatoEletronico, Long id) {
		// busca no banco de dados para garantir que o contato eletronico não seja nulo
		ContatoEletronico contatoEletronicoPesquisado = pesquisarPorId(id);
		/*
		 * copia dos novos dados para que não seja persistido os mesmo dados que ja
		 * existiam no banco
		 */
		BeanUtils.copyProperties(contatoEletronico, contatoEletronicoPesquisado, "id");
		return contatoEletronicoRepository.save(contatoEletronicoPesquisado);
	}

	@Transactional
	public void excluir(Long id) {
		contatoEletronicoRepository.deleteById(id);
	}

	public List<ContatoEletronico> listar() {
		return contatoEletronicoRepository.findAll();
	}
}
