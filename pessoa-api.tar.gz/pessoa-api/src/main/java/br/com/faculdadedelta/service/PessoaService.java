package br.com.faculdadedelta.service;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.faculdadedelta.model.Pessoa;
import br.com.faculdadedelta.model.PessoaFisica;
import br.com.faculdadedelta.repository.PessoaRepository;

@Service
public class PessoaService {

	@Autowired
	private PessoaRepository pessoaRepository;

	@Transactional
	public Pessoa inserir(Pessoa pessoa) {
		pessoa.setId(null);
		return pessoaRepository.save(pessoa);
	}

	public Pessoa pesquisarPorId(Long id) {
		return pessoaRepository.findById(id).orElseThrow(() -> new EmptyResultDataAccessException(1));
	}

	@Transactional
	public Pessoa alterar(Pessoa pessoa, Long id) {
		// busca no banco de dados para garantir que a pessoa não seja nulo
		Pessoa pessoaPesquisado = pesquisarPorId(id);
		/*
		 * copia dos novos dados para que não seja persistido os mesmo dados que ja
		 * existiam no banco
		 */
		BeanUtils.copyProperties(pessoa, pessoaPesquisado, "id");
		return pessoaRepository.save(pessoaPesquisado);
	}

	@Transactional
	public void excluir(Long id) {
		pessoaRepository.deleteById(id);
	}

	public List<Pessoa> listar() {
		return pessoaRepository.findAll();
	}
	
	Pessoa pessoaFisica = new PessoaFisica();
	
	
	
}
