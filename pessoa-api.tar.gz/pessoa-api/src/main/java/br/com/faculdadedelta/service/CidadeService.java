package br.com.faculdadedelta.service;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.faculdadedelta.model.Cidade;
import br.com.faculdadedelta.repository.CidadeRepository;

@Service
public class CidadeService {

	@Autowired
	private CidadeRepository cidadeRepository;

	@Transactional
	public Cidade inserir(Cidade cidade) {
		cidade.setId(null);
		return cidadeRepository.save(cidade);
	}

	public Cidade pesquisarPorId(Long id) {
		return cidadeRepository.findById(id).orElseThrow(() -> new EmptyResultDataAccessException(1));
	}

	@Transactional
	public Cidade alterar(Cidade cidade, Long id) {
		// busca no banco de dados para garantir que a cidade não seja nulo
		Cidade cidadePesquisado = pesquisarPorId(id);
		/*
		 * copia dos novos dados para que não seja persistido os mesmo dados que ja
		 * existiam no banco
		 */
		BeanUtils.copyProperties(cidade, cidadePesquisado, "id");
		return cidadeRepository.save(cidadePesquisado);
	}

	@Transactional
	public void excluir(Long id) {
		cidadeRepository.deleteById(id);
	}

	public List<Cidade> listar() {
		return cidadeRepository.findAll();
	}
}
