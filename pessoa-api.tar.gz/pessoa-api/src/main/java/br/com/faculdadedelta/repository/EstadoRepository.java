package br.com.faculdadedelta.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.faculdadedelta.model.Estado;

public interface EstadoRepository extends JpaRepository<Estado, Long>{

}



