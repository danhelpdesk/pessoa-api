package br.com.faculdadedelta.service;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.faculdadedelta.model.Profissao;
import br.com.faculdadedelta.repository.ProfissaoRepository;

@Service
public class ProfissaoService {

	@Autowired
	private ProfissaoRepository profissaoRepository;

	@Transactional
	public Profissao inserir(Profissao profissao) {
		profissao.setId(null);
		return profissaoRepository.save(profissao);
	}

	public Profissao pesquisarPorId(Long id) {
		return profissaoRepository.findById(id).orElseThrow(() -> new EmptyResultDataAccessException(1));
	}

	@Transactional
	public Profissao alterar(Profissao profissao, Long id) {
		// busca no banco de dados para garantir que a profissao não seja nulo
		Profissao profissaoPesquisado = pesquisarPorId(id);
		/*
		 * copia dos novos dados para que não seja persistido os mesmo dados que ja
		 * existiam no banco
		 */
		BeanUtils.copyProperties(profissao, profissaoPesquisado, "id");
		return profissaoRepository.save(profissaoPesquisado);
	}

	@Transactional
	public void excluir(Long id) {
		profissaoRepository.deleteById(id);
	}

	public List<Profissao> listar() {
		return profissaoRepository.findAll();
	}
}
