package br.com.faculdadedelta.resource;

import java.net.URI;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import br.com.faculdadedelta.model.Foto;
import br.com.faculdadedelta.service.FotoService;

@RestController
@RequestMapping("/fotos")
public class FotoResource {

	@Autowired
	private FotoService fotoService;

	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	public Foto inserir(@RequestBody @Valid Foto foto, HttpServletResponse response) {

		Foto fotoCadastrado = fotoService.inserir(foto);

		URI uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(foto.getId()).toUri();

		response.setHeader(HttpHeaders.LOCATION, uri.toString());

		return fotoCadastrado;
	}

	@GetMapping
	@ResponseStatus(HttpStatus.OK)
	public List<Foto> listar() {
		return fotoService.listar();
	}

	@GetMapping("/{id}")
	@ResponseStatus(HttpStatus.OK)
	public Foto pesquisarPorId(@PathVariable("id") Long id) {
		return fotoService.pesquisarPorId(id);
	}

	@PutMapping("/{id}")
	@ResponseStatus(HttpStatus.OK)
	public Foto alterar(@RequestBody @Valid Foto foto, @PathVariable("id") Long id) {
		return fotoService.alterar(foto, id);
	}

	@DeleteMapping("/{id}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void excluir(@PathVariable("id") Long id) {
		fotoService.excluir(id);
	}

}
