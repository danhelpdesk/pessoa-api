package br.com.faculdadedelta.resource;

import java.net.URI;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import br.com.faculdadedelta.model.Observacao;
import br.com.faculdadedelta.service.ObservacaoService;

@RestController
@RequestMapping("/observacoes")
public class ObservacaoResource {

	@Autowired
	private ObservacaoService observacaoService;

	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	public Observacao inserir(@RequestBody @Valid Observacao observacao, HttpServletResponse response) {

		Observacao observacaoCadastrado = observacaoService.inserir(observacao);

		URI uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(observacao.getId())
				.toUri();

		response.setHeader(HttpHeaders.LOCATION, uri.toString());

		return observacaoCadastrado;
	}

	@GetMapping
	@ResponseStatus(HttpStatus.OK)
	public List<Observacao> listar() {
		return observacaoService.listar();
	}

	@GetMapping("/{id}")
	@ResponseStatus(HttpStatus.OK)
	public Observacao pesquisarPorId(@PathVariable("id") Long id) {
		return observacaoService.pesquisarPorId(id);
	}

	@PutMapping("/{id}")
	@ResponseStatus(HttpStatus.OK)
	public Observacao alterar(@RequestBody @Valid Observacao observacao, @PathVariable("id") Long id) {
		return observacaoService.alterar(observacao, id);
	}

	@DeleteMapping("/{id}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void excluir(@PathVariable("id") Long id) {
		observacaoService.excluir(id);
	}

}
